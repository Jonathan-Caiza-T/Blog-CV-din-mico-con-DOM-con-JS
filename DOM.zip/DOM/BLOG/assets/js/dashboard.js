
document.addEventListener("DOMContentLoaded", () => {

    //Cargar componentes
    const includes = document.querySelectorAll("[data-include]");

    includes.forEach(el => {
        const file = el.getAttribute("data-include");

        fetch(file)
            .then(response => response.text())
            .then(data => {
                el.innerHTML = data;
            })
            .catch(() => {
                el.innerHTML = "<p>Error al cargar componente</p>";
            });
    });

    //Contador dinámico de proyectos
    const proyectos = 3; // simulación
    const proyectosCount = document.getElementById("proyectosCount");

    if (proyectosCount) {
        proyectosCount.textContent = `${proyectos} Registrados`;
    }

    //Efecto interactivo en las cards
    const cards = document.querySelectorAll(".card");

    cards.forEach(card => {
        card.addEventListener("mouseenter", () => {
            card.style.transform = "scale(1.05)";
            card.style.transition = "0.3s";
        });

        card.addEventListener("mouseleave", () => {
            card.style.transform = "scale(1)";
        });
    });

    //Mensaje al crear proyecto
    const btnNuevo = document.querySelector(".btn-nuevo");

    if (btnNuevo) {
        btnNuevo.addEventListener("click", () => {
            alert("Redirigiendo a creación de proyecto...");
        });
    }

});
