const formRegistro = document.getElementById("registroForm");

formRegistro.addEventListener("submit", function (e) {
    e.preventDefault();

    const user = {
        nombres: document.getElementById("nombres").value.trim(),
        apellidos: document.getElementById("apellidos").value.trim(),
        cedula: document.getElementById("cedula").value.trim(),
        fecha: document.getElementById("fecha").value,
        email: document.getElementById("email").value.trim(),
        direccion: document.getElementById("direccion").value.trim(),
        username: document.getElementById("username").value.trim(),
        password: document.getElementById("password").value.trim(),
    };

    // Validar campos
    if (Object.values(user).some(v => v === "")) {
        alert("Por favor completa todos los campos.");
        return;
    }

    const users = JSON.parse(localStorage.getItem("users")) || [];

    // Validar duplicados
    const existe = users.some(
        u => u.email === user.email || u.username === user.username
    );

    if (existe) {
        alert("El correo o usuario ya está registrado.");
        return;
    }

    users.push(user);
    localStorage.setItem("users", JSON.stringify(users));

    alert("Registro exitoso. Ahora puedes iniciar sesión.");
    window.location.href = "login.html";
});
