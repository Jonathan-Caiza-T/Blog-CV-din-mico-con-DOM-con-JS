document.addEventListener("DOMContentLoaded", () => {

    const enlaces = document.querySelectorAll('a[href^="#"]');

    enlaces.forEach(enlace => {
        enlace.addEventListener("click", e => {
            e.preventDefault();
            const destino = document.querySelector(enlace.getAttribute("href"));
            if (destino) {
                destino.scrollIntoView({ behavior: "smooth" });
            }
        });
    });

    //Menu
    const secciones = document.querySelectorAll("section");
    const menuLinks = document.querySelectorAll(".navbar_menu a");

    window.addEventListener("scroll", () => {
        let current = "";

        secciones.forEach(section => {
            const sectionTop = section.offsetTop - 100;
            if (scrollY >= sectionTop) {
                current = section.getAttribute("id");
            }
        });

        menuLinks.forEach(link => {
            link.classList.remove("active");
            if (link.getAttribute("href") === `#${current}`) {
                link.classList.add("active");
            }
        });
    });

    //Scroll
    const elementos = document.querySelectorAll(".section, .card");

    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = "1";
                entry.target.style.transform = "translateY(0)";
            }
        });
    }, { threshold: 0.2 });

    elementos.forEach(el => {
        el.style.opacity = "0";
        el.style.transform = "translateY(40px)";
        el.style.transition = "all 0.6s ease";
        observer.observe(el);
    });

    //Tarjetas
    const cards = document.querySelectorAll(".card");

    cards.forEach((card, index) => {

        card.addEventListener("mouseenter", () => {
            card.style.transform = "scale(1.05)";
            card.style.boxShadow = "0 10px 25px rgba(0,0,0,0.2)";
        });

        card.addEventListener("mouseleave", () => {
            card.style.transform = "scale(1)";
            card.style.boxShadow = "none";
        });

        card.addEventListener("click", () => {
            alert(`Proyecto seleccionado: Proyecto #${index + 1}`);
        });
    });

    //Hero
    const titulo = document.querySelector(".principal-title");
    const texto = titulo.textContent;
    titulo.textContent = "";
    let i = 0;

    function escribirTexto() {
        if (i < texto.length) {
            titulo.textContent += texto.charAt(i);
            i++;
            setTimeout(escribirTexto, 70);
        }
    }
    escribirTexto();

    //Volver arriba
    const btnTop = document.createElement("button");
    btnTop.textContent = "⬆";
    btnTop.style.position = "fixed";
    btnTop.style.bottom = "20px";
    btnTop.style.right = "20px";
    btnTop.style.padding = "10px 15px";
    btnTop.style.display = "none";
    btnTop.style.cursor = "pointer";
    btnTop.style.borderRadius = "50%";

    document.body.appendChild(btnTop);

    window.addEventListener("scroll", () => {
        btnTop.style.display = window.scrollY > 400 ? "block" : "none";
    });

    btnTop.addEventListener("click", () => {
        window.scrollTo({ top: 0, behavior: "smooth" });
    });

    //Redes
    const btnCV = document.querySelector(".btn_light");
    if (btnCV) {
        btnCV.addEventListener("click", () => {
            alert("Descarga de CV próximamente 📄");
        });
    }

    const redes = document.querySelectorAll(".socials a");
    redes.forEach(red => {
        red.addEventListener("click", () => {
            alert("Red social aún no disponible 🚧");
        });
    });

});
